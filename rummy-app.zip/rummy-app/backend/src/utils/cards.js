/**
 * Classic Indian Rummy — Card & Deck Utilities
 *
 * Standard 52-card deck (no jokers in base deck).
 * 2 printed jokers are added per Indian Rummy rules.
 * A wild joker is selected randomly after dealing.
 *
 * Card codes: "S"=Spades, "H"=Hearts, "D"=Diamonds, "C"=Clubs
 * Ranks: "A","2".."10","J","Q","K"
 * Jokers: "J1","J2" (printed), wild determined per game
 */

const SUITS = ['S', 'H', 'D', 'C'];
const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
const PRINTED_JOKERS = ['J1', 'J2'];

const RANK_ORDER = { A: 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, J: 11, Q: 12, K: 13 };

/** Create a full 52-card deck + 2 printed jokers */
function createDeck() {
  const deck = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      deck.push(suit + rank);
    }
  }
  deck.push(...PRINTED_JOKERS);
  return deck;
}

/** Fisher-Yates shuffle with cryptographic randomness */
function shuffleDeck(deck, seed) {
  const arr = [...deck];
  // Use provided seed + crypto for deterministic but secure shuffles
  let rngSeed = seed || require('crypto').randomBytes(16).toString('hex');

  for (let i = arr.length - 1; i > 0; i--) {
    const hash = require('crypto').createHash('sha256')
      .update(rngSeed + ':' + i).digest('hex');
    const j = parseInt(hash.substring(0, 8), 16) % (i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/** Get rank value (for points calculation) */
function rankValue(rank) {
  if (RANK_ORDER[rank]) return Math.min(RANK_ORDER[rank], 10); // Face cards = 10
  return 0; // Jokers = 0 points
}

/** Get card points */
function cardPoints(cardCode) {
  if (cardCode.startsWith('J')) return 0; // Jokers = 0
  const rank = cardCode.substring(1);
  return RANK_ORDER[rank] ? Math.min(RANK_ORDER[rank], 10) : 0;
}

/** Card display name */
function cardDisplay(cardCode) {
  if (cardCode === 'J1') return '★ PJ1';
  if (cardCode === 'J2') return '★ PJ2';
  const suitMap = { S: '♠', H: '♥', D: '♦', C: '♣' };
  const suit = suitMap[cardCode[0]] || cardCode[0];
  return `${suit}${cardCode.substring(1)}`;
}

/** Sort cards by suit then rank */
function sortBySuit(cards) {
  const suitOrder = { S: 0, H: 1, D: 2, C: 3, J: 4 };
  return [...cards].sort((a, b) => {
    const sa = suitOrder[a[0]] ?? 9;
    const sb = suitOrder[b[0]] ?? 9;
    if (sa !== sb) return sa - sb;
    return (RANK_ORDER[a.substring(1)] || 0) - (RANK_ORDER[b.substring(1)] || 0);
  });
}

/** Sort cards by rank */
function sortByRank(cards) {
  return [...cards].sort((a, b) => {
    return (RANK_ORDER[a.substring(1)] || 0) - (RANK_ORDER[b.substring(1)] || 0);
  });
}

/** Deal cards to N players */
function dealHands(deck, numPlayers, cardsPerPlayer = 13) {
  const hands = Array.from({ length: numPlayers }, () => []);
  for (let i = 0; i < cardsPerPlayer; i++) {
    for (let p = 0; p < numPlayers; p++) {
      if (deck.length > 0) hands[p].push(deck.shift());
    }
  }
  return hands;
}

module.exports = {
  SUITS, RANKS, PRINTED_JOKERS, RANK_ORDER,
  createDeck, shuffleDeck, rankValue, cardPoints, cardDisplay,
  sortBySuit, sortByRank, dealHands,
};
