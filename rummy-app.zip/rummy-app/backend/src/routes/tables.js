const { Router } = require('express');
const db = require('../config/database');
const { authMiddleware } = require('../middleware/auth');
const { validate, tableSchema } = require('../middleware/validate');
const { tableCreateLimiter } = require('../middleware/rateLimiter');
const logger = require('../config/logger');

const router = Router();

// ─── List Tables ─────────────────────────────────────────
router.get('/', authMiddleware, async (req, res) => {
  try {
    const { type, variant, entry_fee_min, entry_fee_max, page = 1, limit = 20 } = req.query;
    const conditions = [];
    const values = [];
    let idx = 1;

    if (type) { conditions.push(`t.table_type = $${idx++}`); values.push(type); }
    if (variant) { conditions.push(`t.variant = $${idx++}`); values.push(variant); }
    if (entry_fee_min) { conditions.push(`t.entry_fee >= $${idx++}`); values.push(parseInt(entry_fee_min)); }
    if (entry_fee_max) { conditions.push(`t.entry_fee <= $${idx++}`); values.push(parseInt(entry_fee_max)); }

    const where = conditions.length > 0 ? 'WHERE ' + conditions.join(' AND ') : '';

    const { rows } = await db.query(
      `SELECT * FROM v_active_tables t
       ${where}
       ORDER BY t.prize_pool DESC
       LIMIT $${idx} OFFSET $${idx + 1}`,
      [...values, parseInt(limit), (parseInt(page) - 1) * parseInt(limit)]
    );

    res.json({ tables: rows, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    logger.error('List tables error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch tables.' } });
  }
});

// ─── Create Table ────────────────────────────────────────
router.post('/', authMiddleware, tableCreateLimiter, validate(tableSchema), async (req, res) => {
  try {
    const { variant, table_type, max_players, entry_fee, turn_duration } = req.validated;

    // Check chips if entry fee
    if (entry_fee > 0) {
      const { rows } = await db.query('SELECT chips_balance FROM users WHERE id = $1', [req.user.id]);
      if (rows[0].chips_balance < entry_fee) {
        return res.status(402).json({ error: { code: 'INSUFFICIENT_CHIPS', message: 'Not enough chips for entry fee.' } });
      }
      // Deduct entry fee
      await db.query('UPDATE users SET chips_balance = chips_balance - $1 WHERE id = $2', [entry_fee, req.user.id]);
    }

    // Generate unique table code
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let tableCode;
    let attempts = 0;
    do {
      tableCode = Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
      const check = await db.query('SELECT id FROM game_tables WHERE table_code = $1', [tableCode]);
      if (check.rows.length === 0) break;
      attempts++;
    } while (attempts < 10);

    const prizePool = entry_fee * max_players;

    const { rows } = await db.query(
      `INSERT INTO game_tables (table_code, table_type, variant, max_players, entry_fee, prize_pool, turn_duration, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING *`,
      [tableCode, table_type, variant, max_players, entry_fee, prizePool, turn_duration, req.user.id]
    );

    logger.info(`Table created: ${tableCode} by ${req.user.username}`);

    res.status(201).json(rows[0]);
  } catch (err) {
    logger.error('Create table error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to create table.' } });
  }
});

// ─── Get Table ────────────────────────────────────────────
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT t.*, u.username AS creator_name, u.display_name AS creator_display
       FROM game_tables t
       JOIN users u ON u.id = t.created_by
       WHERE t.id = $1`,
      [req.params.id]
    );
    if (!rows.length) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Table not found.' } });
    }

    const { rows: players } = await db.query(
      `SELECT tp.seat_index, tp.joined_at,
              u.id, u.username, u.display_name, u.avatar_url, u.vip_level
       FROM table_players tp
       JOIN users u ON u.id = tp.user_id
       WHERE tp.table_id = $1
       ORDER BY tp.seat_index`,
      [req.params.id]
    );

    res.json({ ...rows[0], players });
  } catch (err) {
    logger.error('Get table error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch table.' } });
  }
});

// ─── Join By Code ────────────────────────────────────────
router.post('/join-by-code', authMiddleware, async (req, res) => {
  try {
    const { table_code } = req.body;
    if (!table_code) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Table code required.' } });
    }

    const { rows } = await db.query(
      "SELECT * FROM game_tables WHERE table_code = $1 AND status = 'waiting'",
      [table_code.toUpperCase()]
    );
    if (!rows.length) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Table not found or already in progress.' } });
    }

    res.json(rows[0]);
  } catch (err) {
    logger.error('Join by code error:', err);
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Failed to join.' } });
  }
});

module.exports = router;
