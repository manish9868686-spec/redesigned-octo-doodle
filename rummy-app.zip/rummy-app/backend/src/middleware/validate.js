const { z } = require('zod');

const registerSchema = z.object({
  username: z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/, 'Username: letters, numbers, underscore only'),
  email: z.string().email(),
  password: z.string().min(8).max(64),
  phone: z.string().regex(/^\+?[1-9]\d{6,14}$/).optional(),
  display_name: z.string().min(1).max(60).optional(),
});

const loginSchema = z.object({
  login: z.string().min(1).max(100),
  password: z.string().min(1),
  device_info: z.object({
    platform: z.enum(['android', 'ios', 'web']).optional(),
    version: z.string().optional(),
  }).optional(),
});

const tableSchema = z.object({
  variant: z.enum(['points', 'deals', 'pool_101', 'pool_201']),
  table_type: z.enum(['public', 'private', 'tournament']).default('public'),
  max_players: z.number().int().min(2).max(6).default(4),
  entry_fee: z.number().int().min(0).max(1000000).default(0),
  turn_duration: z.number().int().min(10).max(120).default(30),
});

const updateProfileSchema = z.object({
  display_name: z.string().min(1).max(60).optional(),
  avatar_url: z.string().url().optional(),
  preferences: z.object({
    theme: z.enum(['light', 'dark', 'system']).optional(),
    sound: z.boolean().optional(),
    vibration: z.boolean().optional(),
    notify_game_invite: z.boolean().optional(),
    notify_turn: z.boolean().optional(),
    notify_chat: z.boolean().optional(),
  }).optional(),
});

function validate(schema) {
  return (req, res, next) => {
    const result = schema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Invalid input.',
          details: result.error.flatten().fieldErrors,
        },
      });
    }
    req.validated = result.data;
    next();
  };
}

module.exports = { validate, registerSchema, loginSchema, tableSchema, updateProfileSchema };
