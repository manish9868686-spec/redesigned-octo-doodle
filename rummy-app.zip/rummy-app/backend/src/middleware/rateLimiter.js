const rateLimit = require('express-rate-limit');

const generalLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '60000'),
  max: parseInt(process.env.RATE_LIMIT_MAX || '60'),
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.user?.id || req.ip,
  handler: (req, res) => {
    res.status(429).json({ error: { code: 'RATE_LIMITED', message: 'Too many requests, slow down.' } });
  },
});

const authLimiter = rateLimit({
  windowMs: 60000,
  max: 10,
  keyGenerator: (req) => req.ip,
  handler: (req, res) => {
    res.status(429).json({ error: { code: 'RATE_LIMITED', message: 'Too many auth attempts.' } });
  },
});

const tableCreateLimiter = rateLimit({
  windowMs: 60000,
  max: 5,
  keyGenerator: (req) => req.user?.id,
  handler: (req, res) => {
    res.status(429).json({ error: { code: 'RATE_LIMITED', message: 'Table creation limit reached.' } });
  },
});

module.exports = { generalLimiter, authLimiter, tableCreateLimiter };
