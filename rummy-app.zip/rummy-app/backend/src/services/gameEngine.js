/**
 * Classic Indian Rummy — Game Engine
 *
 * Manages game state, turns, and rules for a single rummy table.
 * This is the core state machine that runs per table.
 */

const {
  createDeck, shuffleDeck, dealHands,
  cardPoints, sortBySuit, sortByRank,
} = require('../utils/cards');

const { validateDeclaration, findBestMelds, calculateDeadwood } = require('../utils/validator');

class GameEngine {
  constructor(tableId, variant, maxPlayers) {
    this.tableId = tableId;
    this.variant = variant;        // 'points' | 'deals' | 'pool_101' | 'pool_201'
    this.maxPlayers = maxPlayers;
    this.players = new Map();      // seatIndex → { userId, username, hand, melds, score, status }
    this.seats = new Array(maxPlayers).fill(null);

    // Game state
    this.deck = [];
    this.discardPile = [];
    this.wildJoker = null;
    this.currentTurn = -1;
    this.turnPhase = 'draw';       // 'draw' | 'discard' | 'declare' | 'finished'
    this.turnStartTime = null;
    this.turnDuration = 30;        // seconds
    this.dealerSeat = 0;

    // Round tracking
    this.roundNumber = 0;
    this.roundHistory = [];

    // Score tracking (for deals/pool variants)
    this.playerScores = {};        // userId → cumulative score

    // Server seed for provably fair shuffling
    this.shuffleSeed = require('crypto').randomBytes(32).toString('hex');
    this.shuffleSeedHash = require('crypto')
      .createHash('sha256').update(this.shuffleSeed).digest('hex');
  }

  /** Add a player to a seat */
  addPlayer(userId, username, seatIndex) {
    if (this.seats[seatIndex]) return false;
    this.seats[seatIndex] = { userId, username };
    this.players.set(seatIndex, {
      userId, username, hand: [], melds: [],
      score: this.playerScores[userId] || 0,
      status: 'active', // 'active' | 'declared' | 'dropped' | 'finished'
      isReady: false,
    });
    return true;
  }

  /** Remove a player */
  removePlayer(seatIndex) {
    if (!this.seats[seatIndex]) return false;
    const userId = this.seats[seatIndex].userId;
    this.players.delete(seatIndex);
    this.seats[seatIndex] = null;
    return userId;
  }

  /** Mark player as ready */
  setReady(seatIndex) {
    if (this.players.has(seatIndex)) {
      this.players.get(seatIndex).isReady = true;
    }
  }

  /** Check if all seated players are ready */
  allReady() {
    const seated = this.seats.filter(s => s !== null).length;
    if (seated < 2) return false;
    let ready = 0;
    for (const [seat, player] of this.players) {
      if (player.isReady) ready++;
    }
    return ready >= seated && seated >= 2;
  }

  /** Start a new round */
  startRound() {
    this.roundNumber++;

    // Create and shuffle deck
    let fullDeck = createDeck();
    // For 2-player games, use 2 decks
    if (this.getPlayerCount() === 2) {
      fullDeck = [...fullDeck, ...createDeck()];
    }

    this.deck = shuffleDeck(fullDeck, this.shuffleSeed + ':' + this.roundNumber);

    // Deal hands
    const numPlayers = this.getPlayerCount();
    const hands = dealHands(this.deck, numPlayers, 13);

    // Assign hands to seated players
    let handIdx = 0;
    for (let i = 0; i < this.maxPlayers; i++) {
      const player = this.players.get(i);
      if (player) {
        player.hand = hands[handIdx++];
        player.melds = [];
        player.status = 'active';
        player.isReady = true; // ready for this round
      }
    }

    // Select wild joker (first card of remaining deck or top card)
    if (this.deck.length > 0) {
      this.wildJoker = this.deck.pop();
      // Place it at the bottom face-up, but for simplicity: store and make any same-rank card wild
      const wildRank = this.wildJoker.substring(1);
      // All cards of this rank become wild jokers
      // We'll also add the actual wildJoker card back to deck (face up at bottom)
      this.deck.push(this.wildJoker);
    } else {
      this.wildJoker = 'J1'; // fallback
    }

    // Initialize discard pile with top card of deck
    if (this.deck.length > 0) {
      this.discardPile = [this.deck.pop()];
    }

    // Set dealer and first turn
    this.dealerSeat = (this.dealerSeat + 1) % this.maxPlayers;
    while (!this.players.has(this.dealerSeat)) {
      this.dealerSeat = (this.dealerSeat + 1) % this.maxPlayers;
    }

    // First player after dealer
    this.currentTurn = this.getNextActiveSeat(this.dealerSeat);
    this.turnPhase = 'draw';
    this.turnStartTime = Date.now();

    return this.getPublicState();
  }

  /** Get next active seat after given seat */
  getNextActiveSeat(currentSeat) {
    for (let i = 1; i <= this.maxPlayers; i++) {
      const seat = (currentSeat + i) % this.maxPlayers;
      const player = this.players.get(seat);
      if (player && player.status === 'active') return seat;
    }
    return -1;
  }

  /** Number of active players */
  getActivePlayerCount() {
    let count = 0;
    for (const [, player] of this.players) {
      if (player.status === 'active') count++;
    }
    return count;
  }

  /** Total seated players */
  getPlayerCount() {
    return this.seats.filter(s => s !== null).length;
  }

  /** Player draws from closed pile */
  drawFromPile(seatIndex) {
    if (this.currentTurn !== seatIndex || this.turnPhase !== 'draw') {
      return { error: 'NOT_YOUR_TURN' };
    }

    const player = this.players.get(seatIndex);
    if (!player || player.status !== 'active') return { error: 'INVALID_PLAYER' };

    if (this.deck.length === 0) {
      // Reshuffle discard pile into deck (keep top card)
      if (this.discardPile.length <= 1) return { error: 'NO_CARDS' };
      const topDiscard = this.discardPile.pop();
      this.deck = shuffleDeck(this.discardPile, this.shuffleSeed + ':reshuffle:' + this.roundNumber);
      this.discardPile = [topDiscard];
    }

    const card = this.deck.pop();
    player.hand.push(card);
    this.turnPhase = 'discard';

    return this.getPublicState();
  }

  /** Player draws from discard pile */
  drawFromDiscard(seatIndex) {
    if (this.currentTurn !== seatIndex || this.turnPhase !== 'draw') {
      return { error: 'NOT_YOUR_TURN' };
    }

    const player = this.players.get(seatIndex);
    if (!player || player.status !== 'active') return { error: 'INVALID_PLAYER' };

    if (this.discardPile.length === 0) return { error: 'NO_DISCARD' };

    const card = this.discardPile.pop();
    player.hand.push(card);
    this.turnPhase = 'discard';

    return this.getPublicState();
  }

  /** Player discards a card */
  discard(seatIndex, cardCode) {
    if (this.currentTurn !== seatIndex || this.turnPhase !== 'discard') {
      return { error: 'NOT_YOUR_TURN' };
    }

    const player = this.players.get(seatIndex);
    if (!player || player.status !== 'active') return { error: 'INVALID_PLAYER' };

    const idx = player.hand.indexOf(cardCode);
    if (idx === -1) return { error: 'CARD_NOT_IN_HAND' };

    player.hand.splice(idx, 1);
    this.discardPile.push(cardCode);

    // Advance turn
    this.currentTurn = this.getNextActiveSeat(seatIndex);
    this.turnPhase = 'draw';
    this.turnStartTime = Date.now();

    return this.getPublicState();
  }

  /** Player declares their hand */
  declare(seatIndex, meldGroups) {
    if (this.currentTurn !== seatIndex) return { error: 'NOT_YOUR_TURN' };

    const player = this.players.get(seatIndex);
    if (!player || player.status !== 'active') return { error: 'INVALID_PLAYER' };

    const wildRank = this.wildJoker ? this.wildJoker.substring(1) : null;
    const wildCardCode = this.wildJoker;

    // Build wild joker list: printed jokers + all cards of wild rank
    const validation = validateDeclaration(player.hand, meldGroups, wildCardCode);

    if (!validation.valid) {
      // Invalid declaration = penalty (80 points for first wrong declare, 160 for subsequent)
      return { error: 'INVALID_DECLARE', reason: validation.reason };
    }

    // Valid declaration!
    player.status = 'declared';
    player.melds = meldGroups;
    player.handDeadwood = 0;

    // Other players get one more turn to minimize points, or game ends
    this.turnPhase = 'declare';
    this.currentTurn = seatIndex;

    return this.getPublicState();
  }

  /** Player drops out (valid only on first turn — 20 pts penalty; after — 40 pts) */
  drop(seatIndex, isFirstTurn = false) {
    const player = this.players.get(seatIndex);
    if (!player || player.status !== 'active') return { error: 'INVALID' };

    player.status = 'dropped';
    player.dropPenalty = isFirstTurn ? 20 : 40;

    if (this.getActivePlayerCount() <= 1) {
      return this.finishRound();
    }

    // If it was this player's turn, advance
    if (this.currentTurn === seatIndex) {
      this.currentTurn = this.getNextActiveSeat(seatIndex);
      this.turnPhase = 'draw';
    }

    return this.getPublicState();
  }

  /** Finish the round and calculate scores */
  finishRound(declarerSeat = null) {
    const results = [];

    for (let i = 0; i < this.maxPlayers; i++) {
      const player = this.players.get(i);
      if (!player) continue;

      let deadwood = 0;
      let status = player.status;

      if (status === 'declared') {
        deadwood = 0;
      } else if (status === 'dropped') {
        deadwood = player.dropPenalty;
      } else {
        // Calculate deadwood for non-declared players
        const best = findBestMelds(player.hand, this.wildJoker);
        deadwood = Math.min(best.deadwood, 80); // max 80 points for non-declared
      }

      const entry = {
        seatIndex: i,
        userId: player.userId,
        username: player.username,
        deadwood,
        status,
      };

      if (status === 'declared') {
        entry.isWinner = true;
        entry.rank = 1;
      }

      results.push(entry);
      // Update player's cumulative score
      this.playerScores[player.userId] = (this.playerScores[player.userId] || 0) + deadwood;
    }

    // Sort by deadwood ascending (lower = better)
    results.sort((a, b) => a.deadwood - b.deadwood);
    results.forEach((r, i) => { r.rank = i + 1; });

    // Save round history
    this.roundHistory.push({
      roundNumber: this.roundNumber,
      results,
      finishedAt: new Date().toISOString(),
    });

    this.turnPhase = 'finished';

    return { finished: true, results, roundHistory: this.roundHistory };
  }

  /** Get the public game state for all players */
  getPublicState() {
    const players = [];
    for (let i = 0; i < this.maxPlayers; i++) {
      const p = this.players.get(i);
      players.push({
        seatIndex: i,
        username: p?.username || null,
        cardCount: p?.hand?.length || 0,
        status: p?.status || null,
        isReady: p?.isReady || false,
        userId: this.seats[i]?.userId || null,
      });
    }

    return {
      tableId: this.tableId,
      variant: this.variant,
      roundNumber: this.roundNumber,
      currentTurn: this.currentTurn,
      turnPhase: this.turnPhase,
      dealerSeat: this.dealerSeat,
      wildJoker: this.wildJoker,
      discardTop: this.discardPile[this.discardPile.length - 1] || null,
      discardSize: this.discardPile.length,
      deckSize: this.deck.length,
      players,
      turnDuration: this.turnDuration,
      turnStartTime: this.turnStartTime,
      shuffleSeedHash: this.shuffleSeedHash,
    };
  }

  /** Get player-specific private state */
  getPlayerState(seatIndex) {
    const player = this.players.get(seatIndex);
    if (!player) return null;

    return {
      ...this.getPublicState(),
      hand: player.hand,
      melds: player.melds,
      playerScore: this.playerScores[player.userId] || 0,
      shuffleSeed: this.shuffleSeed, // reveal after game ends
    };
  }

  /** Reorder a player's hand */
  reorderHand(seatIndex, newOrder) {
    const player = this.players.get(seatIndex);
    if (!player) return { error: 'INVALID' };

    // Validate that newOrder contains the same cards
    const sorted1 = [...player.hand].sort();
    const sorted2 = [...newOrder].sort();
    if (JSON.stringify(sorted1) !== JSON.stringify(sorted2)) return { error: 'INVALID_HAND' };

    player.hand = [...newOrder];
    return { success: true, hand: player.hand };
  }

  /** Sort hand by suit or rank */
  sortHand(seatIndex, sortBy = 'suit') {
    const player = this.players.get(seatIndex);
    if (!player) return { error: 'INVALID' };

    player.hand = sortBy === 'rank' ? sortByRank(player.hand) : sortBySuit(player.hand);
    return { success: true, hand: player.hand };
  }

  /** Get table code from ID */
  static generateTableCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // No confusing 0/O/1/I
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars[Math.floor(Math.random() * chars.length)];
    }
    return code;
  }
}

module.exports = GameEngine;
