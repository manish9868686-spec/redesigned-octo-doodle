/**
 * Classic Indian Rummy — Push Notification Service
 */

const logger = require('../config/logger');
const db = require('../config/database');

/**
 * Queue a push notification for a user.
 * In production, this would call FCM / APNs.
 */
async function sendPushNotification(userId, title, body, data = {}) {
  try {
    // Get user's device tokens
    const { rows } = await db.query(
      'SELECT device_tokens, preferences FROM users WHERE id = $1',
      [userId]
    );
    if (!rows.length) return;

    const user = rows[0];
    const tokens = user.device_tokens || [];
    if (!tokens.length) return;

    // Queue notification
    await db.query(
      'INSERT INTO notification_queue (user_id, title, body, data) VALUES ($1,$2,$3,$4)',
      [userId, title, body, JSON.stringify(data)]
    );

    // In production: send via FCM/APNs SDK
    // const admin = require('firebase-admin');
    // await admin.messaging().sendMulticast({
    //   tokens,
    //   notification: { title, body },
    //   data: Object.fromEntries(Object.entries(data).map(([k,v]) => [k, String(v)])),
    // });

    logger.debug(`Push queued for ${userId}: ${title}`);
  } catch (err) {
    logger.error('Push notification error:', err);
  }
}

/**
 * Send notification to all players at a table except the sender.
 */
async function sendTableNotification(tableId, excludeUserId, title, body, data = {}) {
  try {
    const { rows } = await db.query(
      'SELECT user_id FROM table_players WHERE table_id = $1 AND user_id != $2',
      [tableId, excludeUserId]
    );
    for (const row of rows) {
      await sendPushNotification(row.user_id, title, body, data);
    }
  } catch (err) {
    logger.error('Table notification error:', err);
  }
}

module.exports = { sendPushNotification, sendTableNotification };
