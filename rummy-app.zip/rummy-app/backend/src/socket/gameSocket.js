/**
 * Classic Indian Rummy — WebSocket Game Server
 *
 * Manages all real-time game communication via Socket.io.
 * One GameEngine instance per active table.
 */

const { Server } = require('socket.io');
const { socketAuthMiddleware } = require('../middleware/auth');
const logger = require('../config/logger');
const db = require('../config/database');
const GameEngine = require('../services/gameEngine');
const { sendPushNotification } = require('../services/notifications');

// In-memory game state (production: use Redis for horizontal scaling)
const activeGames = new Map();   // tableId → GameEngine
const userSockets = new Map();   // userId → Set<socketId>
const socketToUser = new Map();  // socketId → { userId, username, currentTable }

function initSocketServer(httpServer) {
  const io = new Server(httpServer, {
    cors: {
      origin: '*', // Restrict in production
      methods: ['GET', 'POST'],
    },
    pingInterval: 25000,
    pingTimeout: 20000,
    connectTimeout: 10000,
  });

  // Auth middleware
  io.use(socketAuthMiddleware);

  io.on('connection', async (socket) => {
    const userId = socket.userId;
    const username = socket.username;

    logger.info(`Socket connected: ${username} (${userId})`);

    // Track connection
    if (!userSockets.has(userId)) userSockets.set(userId, new Set());
    userSockets.get(userId).add(socket.id);
    socketToUser.set(socket.id, { userId, username, currentTable: null });

    // Update user status
    await db.query(
      "UPDATE users SET status = 'online', last_seen = NOW() WHERE id = $1",
      [userId]
    );

    // ─── Table Management ───────────────────────────

    socket.on('table:join', async ({ tableId }) => {
      try {
        await handleTableJoin(io, socket, userId, username, tableId);
      } catch (err) {
        socket.emit('game:error', { code: 'JOIN_FAILED', message: err.message });
      }
    });

    socket.on('table:leave', async () => {
      try {
        await handleTableLeave(io, socket, userId);
      } catch (err) {
        socket.emit('game:error', { code: 'LEAVE_FAILED', message: err.message });
      }
    });

    socket.on('table:ready', ({ tableId }) => {
      handleReady(io, socket, userId, tableId);
    });

    // ─── Game Actions ───────────────────────────────

    socket.on('game:draw_pile', ({ tableId }) => {
      handleAction(io, socket, tableId, (game, seat) => game.drawFromPile(seat));
    });

    socket.on('game:draw_discard', ({ tableId }) => {
      handleAction(io, socket, tableId, (game, seat) => game.drawFromDiscard(seat));
    });

    socket.on('game:discard', ({ tableId, cardCode }) => {
      handleAction(io, socket, tableId, (game, seat) => game.discard(seat, cardCode));
    });

    socket.on('game:declare', ({ tableId, meldGroups }) => {
      handleDeclare(io, socket, tableId, meldGroups, userId);
    });

    socket.on('game:drop', ({ tableId }) => {
      handleDrop(io, socket, tableId, userId);
    });

    socket.on('game:reorder', ({ tableId, hand }) => {
      handleAction(io, socket, tableId, (game, seat) => {
        const result = game.reorderHand(seat, hand);
        if (!result.error) {
          // Only send back to this player (private state)
          socket.emit('game:hand_update', { hand: result.hand });
        }
        return result;
      });
    });

    socket.on('game:sort', ({ tableId, sortBy }) => {
      handleAction(io, socket, tableId, (game, seat) => {
        const result = game.sortHand(seat, sortBy);
        if (!result.error) {
          socket.emit('game:hand_update', { hand: result.hand });
        }
        return result;
      });
    });

    // ─── Chat ────────────────────────────────────────

    socket.on('chat:send', async ({ tableId, message, type = 'text' }) => {
      try {
        const info = socketToUser.get(socket.id);
        if (!info?.currentTable || info.currentTable !== tableId) return;

        // Save to DB
        const { rows } = await db.query(
          'INSERT INTO chat_messages (table_id, user_id, message, message_type) VALUES ($1,$2,$3,$4) RETURNING id, created_at',
          [tableId, userId, message, type]
        );

        io.to(`table:${tableId}`).emit('chat:message', {
          id: rows[0].id,
          userId,
          username: info.username,
          message,
          type,
          createdAt: rows[0].created_at,
        });
      } catch (err) {
        logger.error('Chat send error:', err);
      }
    });

    // ─── Disconnect ──────────────────────────────────

    socket.on('disconnect', async () => {
      logger.info(`Socket disconnected: ${username}`);
      const info = socketToUser.get(socket.id);

      if (info?.currentTable) {
        await handleTableLeave(io, socket, userId);
      }

      // Clean up tracking
      if (userSockets.has(userId)) {
        userSockets.get(userId).delete(socket.id);
        if (userSockets.get(userId).size === 0) {
          userSockets.delete(userId);
          await db.query(
            "UPDATE users SET status = 'offline', last_seen = NOW() WHERE id = $1",
            [userId]
          );
        }
      }
      socketToUser.delete(socket.id);
    });
  });

  return io;
}

// ─── Handler Functions ─────────────────────────────────

async function handleTableJoin(io, socket, userId, username, tableId) {
  // Check table exists
  const { rows } = await db.query(
    'SELECT * FROM game_tables WHERE id = $1', [tableId]
  );
  if (rows.length === 0) throw new Error('Table not found.');
  const table = rows[0];

  if (table.status === 'in_progress') throw new Error('Game already in progress.');

  // Check seat availability
  const { rows: seats } = await db.query(
    'SELECT seat_index FROM table_players WHERE table_id = $1 ORDER BY seat_index', [tableId]
  );
  const takenSeats = new Set(seats.map(s => s.seat_index));

  // Find free seat
  let freeSeat = -1;
  for (let i = 0; i < table.max_players; i++) {
    if (!takenSeats.has(i)) { freeSeat = i; break; }
  }
  if (freeSeat === -1) throw new Error('Table is full.');

  // Insert player
  await db.query(
    'INSERT INTO table_players (table_id, user_id, seat_index) VALUES ($1,$2,$3)',
    [tableId, userId, freeSeat]
  );

  // Init game engine if first player
  if (!activeGames.has(tableId)) {
    const engine = new GameEngine(tableId, table.variant, table.max_players);
    engine.turnDuration = table.turn_duration;
    activeGames.set(tableId, engine);
  }

  const game = activeGames.get(tableId);
  game.addPlayer(userId, username, freeSeat);

  // Join socket room
  socket.join(`table:${tableId}`);
  const info = socketToUser.get(socket.id);
  if (info) info.currentTable = tableId;

  // Notify table
  const state = game.getPublicState();
  io.to(`table:${tableId}`).emit('game:player_joined', {
    userId, username, seatIndex: freeSeat,
  });
  io.to(`table:${tableId}`).emit('table:state_changed', state);

  // Send private state to this player
  socket.emit('game:state', game.getPlayerState(freeSeat));

  logger.info(`${username} joined table ${table.table_code} at seat ${freeSeat}`);
}

async function handleTableLeave(io, socket, userId) {
  const info = socketToUser.get(socket.id);
  if (!info?.currentTable) return;
  const tableId = info.currentTable;
  info.currentTable = null;

  const game = activeGames.get(tableId);
  if (!game) return;

  // Find player's seat
  let seatIndex = -1;
  for (let i = 0; i < game.maxPlayers; i++) {
    const p = game.players.get(i);
    if (p && p.userId === userId) { seatIndex = i; break; }
  }
  if (seatIndex === -1) return;

  game.removePlayer(seatIndex);
  await db.query(
    'DELETE FROM table_players WHERE table_id = $1 AND user_id = $2',
    [tableId, userId]
  );

  socket.leave(`table:${tableId}`);
  socket.emit('game:state', null);

  io.to(`table:${tableId}`).emit('game:player_left', { seatIndex });
  io.to(`table:${tableId}`).emit('table:state_changed', game.getPublicState());

  // Clean up empty games
  if (game.getPlayerCount() === 0) {
    activeGames.delete(tableId);
    await db.query(
      "UPDATE game_tables SET status = 'cancelled' WHERE id = $1", [tableId]
    );
  }
}

function handleReady(io, socket, userId, tableId) {
  const game = activeGames.get(tableId);
  if (!game) return;

  let seatIdx = -1;
  for (let i = 0; i < game.maxPlayers; i++) {
    if (game.seats[i]?.userId === userId) { seatIdx = i; break; }
  }
  if (seatIdx === -1) return;

  game.setReady(seatIdx);

  if (game.allReady()) {
    startGame(io, tableId);
  } else {
    io.to(`table:${tableId}`).emit('table:state_changed', game.getPublicState());
  }
}

async function startGame(io, tableId) {
  const game = activeGames.get(tableId);
  if (!game) return;

  // Update DB
  await db.query(
    "UPDATE game_tables SET status = 'in_progress', started_at = NOW() WHERE id = $1",
    [tableId]
  );

  // Create round record
  const { rows } = await db.query(
    'INSERT INTO game_rounds (table_id, round_number, dealer_seat) VALUES ($1,$2,$3) RETURNING id',
    [tableId, game.roundNumber + 1, game.dealerSeat]
  );

  const state = game.startRound();

  // Log fairness seed
  await db.query(
    'INSERT INTO fairness_logs (table_id, event_type, payload) VALUES ($1,$2,$3)',
    [tableId, 'shuffle_seed', { hash: game.shuffleSeedHash, round: game.roundNumber }]
  );

  // Send public state to all
  io.to(`table:${tableId}`).emit('table:state_changed', state);

  // Send private hands to each player
  for (let i = 0; i < game.maxPlayers; i++) {
    const player = game.players.get(i);
    if (player) {
      const playerState = game.getPlayerState(i);
      // Find socket for this player
      for (const [socketId, info] of socketToUser) {
        if (info.userId === player.userId && info.currentTable === tableId) {
          const sock = io.sockets.sockets.get(socketId);
          if (sock) {
            sock.emit('game:dealt', {
              hand: player.hand,
              dealerSeat: game.dealerSeat,
              wildJoker: game.wildJoker,
            });
            sock.emit('game:turn', { seatIndex: game.currentTurn, phase: game.turnPhase });
          }
        }
      }
    }
  }

  // Notify offline players via push
  for (let i = 0; i < game.maxPlayers; i++) {
    const p = game.players.get(i);
    if (p && !userSockets.has(p.userId)) {
      await sendPushNotification(p.userId, 'Your turn!', 'A new Rummy round has started.');
    }
  }

  logger.info(`Game started at table ${tableId}, round ${game.roundNumber}`);
}

function handleAction(io, socket, tableId, actionFn) {
  const game = activeGames.get(tableId);
  if (!game) {
    socket.emit('game:error', { code: 'NO_GAME', message: 'Game not found.' });
    return;
  }

  const info = socketToUser.get(socket.id);
  let seatIdx = -1;
  for (let i = 0; i < game.maxPlayers; i++) {
    if (game.seats[i]?.userId === info.userId) { seatIdx = i; break; }
  }

  const result = actionFn(game, seatIdx);

  if (result?.error) {
    socket.emit('game:error', { code: result.error, message: result.error });
    return;
  }

  // Broadcast updated state
  const state = game.getPublicState();
  io.to(`table:${tableId}`).emit('table:state_changed', state);

  // Send updated hand to player
  const playerState = game.getPlayerState(seatIdx);
  if (playerState) {
    socket.emit('game:hand_update', { hand: playerState.hand });
  }

  // Notify next player
  const turnPlayer = game.players.get(game.currentTurn);
  if (turnPlayer) {
    for (const [socketId, sInfo] of socketToUser) {
      if (sInfo.userId === turnPlayer.userId && sInfo.currentTable === tableId) {
        const sock = io.sockets.sockets.get(socketId);
        if (sock) sock.emit('game:turn', { seatIndex: game.currentTurn, phase: game.turnPhase });
      }
    }

    // Push notification for offline next player
    if (!userSockets.has(turnPlayer.userId)) {
      sendPushNotification(turnPlayer.userId, 'Your turn!', 'It\'s your turn in Rummy. Make a move!');
    }
  }
}

async function handleDeclare(io, socket, tableId, meldGroups, userId) {
  const game = activeGames.get(tableId);
  if (!game) return;

  const info = socketToUser.get(socket.id);
  let seatIdx = -1;
  for (let i = 0; i < game.maxPlayers; i++) {
    if (game.seats[i]?.userId === userId) { seatIdx = i; break; }
  }

  const result = game.declare(seatIdx, meldGroups);

  if (result?.error) {
    socket.emit('game:error', { code: result.error, message: result.reason || result.error });
    return;
  }

  // If valid declaration, finish the round
  io.to(`table:${tableId}`).emit('game:declared', {
    seatIndex: seatIdx,
    username: info.username,
  });

  const finishResult = game.finishRound(seatIdx);

  if (finishResult.finished) {
    await handleRoundEnd(io, tableId, finishResult.results);
  }
}

async function handleDrop(io, socket, tableId, userId) {
  const game = activeGames.get(tableId);
  if (!game) return;

  let seatIdx = -1;
  for (let i = 0; i < game.maxPlayers; i++) {
    if (game.seats[i]?.userId === userId) { seatIdx = i; break; }
  }

  const isFirstTurn = game.roundHistory.length === 0 &&
    game.currentTurn === seatIdx &&
    game.turnPhase === 'draw';

  const result = game.drop(seatIdx, isFirstTurn);

  if (result?.error) {
    socket.emit('game:error', { code: result.error, message: result.error });
    return;
  }

  if (result.finished) {
    await handleRoundEnd(io, tableId, result.results);
  } else {
    io.to(`table:${tableId}`).emit('table:state_changed', game.getPublicState());
  }
}

async function handleRoundEnd(io, tableId, results) {
  const game = activeGames.get(tableId);
  if (!game) return;

  // Save results to DB
  const { rows: tableRow } = await db.query('SELECT * FROM game_tables WHERE id = $1', [tableId]);
  const table = tableRow[0];

  for (const result of results) {
    const chipsWon = result.rank === 1 ? table.prize_pool || 0 : 0;

    await db.query(
      'INSERT INTO game_results (table_id, user_id, final_score, chips_won, rank) VALUES ($1,$2,$3,$4,$5)',
      [tableId, result.userId, result.deadwood, chipsWon, result.rank]
    );

    // Update leaderboard
    if (result.rank === 1) {
      await db.query(
        `UPDATE leaderboard SET
           games_played = games_played + 1,
           games_won = games_won + 1,
           win_streak = win_streak + 1,
           best_streak = GREATEST(best_streak, win_streak + 1),
           total_points = total_points + $2,
           highest_score = GREATEST(highest_score, $2),
           season_pts = season_pts + $3
         WHERE user_id = $1`,
        [result.userId, result.deadwood, result.rank === 1 ? 100 : 20]
      );
    } else {
      await db.query(
        `UPDATE leaderboard SET
           games_played = games_played + 1,
           win_streak = 0,
           total_points = total_points + $2,
           season_pts = season_pts + $3
         WHERE user_id = $1`,
        [result.userId, result.deadwood, 10]
      );
    }

    // Update user chips
    if (chipsWon > 0) {
      await db.query(
        'UPDATE users SET chips_balance = chips_balance + $1 WHERE id = $2',
        [chipsWon, result.userId]
      );
    }
  }

  // Update table status
  await db.query(
    "UPDATE game_tables SET status = 'finished', finished_at = NOW(), winner_id = $1 WHERE id = $2",
    [results[0]?.userId, tableId]
  );

  // Emit results
  io.to(`table:${tableId}`).emit('game:round_end', {
    results: results.map(r => ({
      ...r,
      chipsWon: r.rank === 1 ? table.prize_pool : 0,
    })),
    nextRoundIn: 15, // seconds until next round or game ends
  });

  // Check achievements
  for (const result of results) {
    await checkAchievements(result.userId);
  }

  // Clean up after delay
  setTimeout(() => {
    activeGames.delete(tableId);
    io.to(`table:${tableId}`).emit('game:session_end', { tableId });
    // Kick all sockets from room
    const room = io.sockets.adapter.rooms.get(`table:${tableId}`);
    if (room) {
      for (const socketId of room) {
        const sock = io.sockets.sockets.get(socketId);
        if (sock) sock.leave(`table:${tableId}`);
      }
    }
  }, 30000);

  logger.info(`Round ended at table ${tableId}, winner: ${results[0]?.username}`);
}

async function checkAchievements(userId) {
  try {
    const { rows: stats } = await db.query(
      'SELECT games_played, games_won, win_streak, best_streak, total_points FROM leaderboard WHERE user_id = $1',
      [userId]
    );
    if (!stats.length) return;

    const { rows: achievements } = await db.query(
      'SELECT a.*, ua.progress, ua.is_completed FROM achievements a JOIN user_achievements ua ON ua.achievement_id = a.id WHERE ua.user_id = $1 AND ua.is_completed = FALSE',
      [userId]
    );

    for (const ach of achievements) {
      const req = ach.requirement;
      let progress = ach.progress;

      switch (req.metric) {
        case 'games_played': progress = stats[0].games_played; break;
        case 'games_won': progress = stats[0].games_won; break;
        case 'win_streak': progress = stats[0].win_streak; break;
        case 'total_points': progress = parseInt(stats[0].total_points); break;
        case 'best_streak': progress = stats[0].best_streak; break;
      }

      if (progress >= req.target && !ach.is_completed) {
        await db.query(
          'UPDATE user_achievements SET progress = $1, is_completed = TRUE, completed_at = NOW() WHERE user_id = $2 AND achievement_id = $3',
          [progress, userId, ach.id]
        );
        await db.query(
          'UPDATE users SET chips_balance = chips_balance + $1, xp_points = xp_points + $2 WHERE id = $3',
          [ach.reward_chips, ach.reward_xp, userId]
        );
      } else if (progress !== ach.progress) {
        await db.query(
          'UPDATE user_achievements SET progress = $1 WHERE user_id = $2 AND achievement_id = $3',
          [progress, userId, ach.id]
        );
      }
    }
  } catch (err) {
    logger.error('Achievement check error:', err);
  }
}

module.exports = { initSocketServer, activeGames };
