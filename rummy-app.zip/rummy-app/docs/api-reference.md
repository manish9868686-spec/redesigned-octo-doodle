# Classic Indian Rummy — API Reference

## Base URL
- **Development:** `http://localhost:3000/api/v1`
- **Production:** `https://api.yourdomain.com/api/v1`

## Authentication
All protected routes require `Authorization: Bearer <access_token>` header.
Access token lifetime: 15 min. Refresh token lifetime: 30 days.

---

## 1. AUTH

### POST /auth/register
Register a new user.
```json
{
  "username": "raj_player",
  "email": "raj@example.com",
  "password": "securePass123",
  "phone": "+919876543210",
  "display_name": "Raj Kumar"
}
```
**Response 201:**
```json
{
  "user": { "id": "uuid", "username": "raj_player", … },
  "tokens": { "access": "jwt…", "refresh": "uuid…" }
}
```

### POST /auth/login
Login with username/email + password.
```json
{
  "login": "raj_player",  // or email
  "password": "securePass123",
  "device_info": { "platform": "android", "version": "1.0.0" }
}
```
**Response 200:** Same as register.

### POST /auth/refresh
```json
{ "refresh_token": "uuid…" }
```
**Response 200:** New access + refresh token pair.

### POST /auth/logout
```json
{ "refresh_token": "uuid…" }
```
**Response 204.**

### GET /auth/me
Get current authenticated user profile.
**Response 200:** Full user object.

---

## 2. USERS

### GET /users/:id
Get public profile of a user.

### PATCH /users/me
Update own profile.
```json
{
  "display_name": "New Name",
  "avatar_url": "https://…",
  "preferences": { "theme": "dark", "sound": true }
}
```

### GET /users/me/stats
Get own game statistics.
```json
{
  "games_played": 47,
  "games_won": 23,
  "win_rate": 48.9,
  "highest_score": 280,
  "best_streak": 5,
  "rank_tier": 2,
  "season_pts": 1250
}
```

### GET /users/search?q=raj&limit=20
Search users by username/display_name.

---

## 3. FRIENDS

### GET /friends
List friends (accepted only).

### GET /friends/requests
List pending friend requests (incoming + outgoing).

### POST /friends/request
```json
{ "friend_id": "uuid" }
```

### PATCH /friends/:id/accept
Accept a pending friend request.

### PATCH /friends/:id/reject
Reject / cancel a friend request.

### DELETE /friends/:id
Remove a friend.

---

## 4. GAME TABLES

### GET /tables
List active tables. Query params: `type`, `variant`, `entry_fee_min`, `entry_fee_max`, `page`, `limit`.

### POST /tables
Create a new table.
```json
{
  "variant": "points",
  "table_type": "public",
  "max_players": 4,
  "entry_fee": 100,
  "turn_duration": 30
}
```

### GET /tables/:id
Get table details including seated players.

### POST /tables/:id/join
Join a table.

### POST /tables/:id/leave
Leave a table (before game starts).

### POST /tables/join-by-code
```json
{ "table_code": "XK4P2M" }
```

---

## 5. GAME PLAY (WebSocket)

Connect: `ws://api.yourdomain.com/ws?token=<access_token>`

### Client → Server Events

| Event | Payload | Description |
|-------|---------|-------------|
| `game:ready` | `{ tableId }` | Player ready to start |
| `game:draw_pile` | `{ tableId }` | Draw from closed pile |
| `game:draw_discard` | `{ tableId }` | Pick from discard pile |
| `game:discard` | `{ tableId, cardCode }` | Discard a card |
| `game:declare` | `{ tableId }` | Declare hand |
| `game:drop` | `{ tableId }` | Drop out (first turn) |
| `game:reorder` | `{ tableId, hand[] }` | Reorder hand cards |
| `game:sort` | `{ tableId, sortBy }` | Sort hand (suit/rank) |
| `chat:send` | `{ tableId, message, type }` | Send chat message |

### Server → Client Events

| Event | Payload | Description |
|-------|---------|-------------|
| `game:state` | full game state | Initial & delta state sync |
| `game:dealt` | `{ hand[], dealerSeat }` | Cards dealt to player |
| `game:turn` | `{ seatIndex, phase }` | Turn changed |
| `game:card_drawn` | `{ seatIndex }` | Card drawn (not revealed) |
| `game:card_discarded` | `{ seatIndex, cardCode }` | Card discarded |
| `game:declared` | `{ seatIndex }` | Player declared |
| `game:round_end` | `{ results[], nextRoundIn }` | Round finished |
| `game:player_joined` | `{ user, seatIndex }` | Player joined |
| `game:player_left` | `{ seatIndex }` | Player left |
| `game:error` | `{ code, message }` | Error |
| `chat:message` | `{ user, message, type }` | Chat message |
| `table:state_changed` | `{ status, players[] }` | Table status update |

---

## 6. LEADERBOARD

### GET /leaderboard?page=1&limit=50&tier=3
Get ranked leaderboard.

### GET /leaderboard/me
Get own rank (even if not in top).

### GET /leaderboard/friends
Leaderboard filtered to friends only.

---

## 7. ACHIEVEMENTS

### GET /achievements
List all achievements with own progress.

### GET /achievements/me
Get own achievement progress.

### POST /achievements/:code/claim
Claim a completed achievement reward.

---

## 8. DAILY REWARDS

### GET /daily-rewards/status
Get today's reward status + streak info.

### POST /daily-rewards/claim
Claim today's daily reward.

---

## 9. CHAT

### GET /tables/:id/messages?before=<timestamp>&limit=50
Get chat history for a table (REST fallback).

---

## 10. TRANSACTIONS

### GET /transactions?page=1&limit=20&type=winning
Transaction history.

### GET /transactions/balance
Current chips balance.

---

## 11. GAME HISTORY

### GET /games/history?page=1&limit=20
Personal game history.
```json
[{
  "game_id": "uuid",
  "variant": "points",
  "finished_at": "ISO8601",
  "rank": 1,
  "score": 0,
  "chips_won": 500,
  "players": […]
}]
```

### GET /games/:id/replay
Get round-by-round replay data.
```json
{
  "rounds": [{
    "round_number": 1,
    "actions": [{ "seat_index": 0, "action_type": "draw_pile", "timestamp": "…" }, …],
    "final_hands": { … }
  }]
}
```

---

## Error Response Format
```json
{
  "error": {
    "code": "TABLE_FULL",
    "message": "This table is already full.",
    "details": {}
  }
}
```

### Error Codes
| Code | HTTP Status | Meaning |
|------|-------------|---------|
| `VALIDATION_ERROR` | 400 | Invalid input |
| `AUTH_REQUIRED` | 401 | Missing/invalid token |
| `FORBIDDEN` | 403 | Insufficient permissions |
| `NOT_FOUND` | 404 | Resource not found |
| `TABLE_FULL` | 409 | Table at capacity |
| `INSUFFICIENT_CHIPS` | 402 | Not enough chips |
| `ALREADY_SEATED` | 409 | Already at table |
| `GAME_IN_PROGRESS` | 409 | Cannot join running game |
| `RATE_LIMITED` | 429 | Too many requests |
| `BANNED` | 403 | Account suspended |
| `INTERNAL_ERROR` | 500 | Server error |

---

## Rate Limits
- Auth endpoints: 10 req/min per IP
- General API: 60 req/min per user
- WebSocket: 30 messages/sec per connection
- Table creation: 5 per minute per user
