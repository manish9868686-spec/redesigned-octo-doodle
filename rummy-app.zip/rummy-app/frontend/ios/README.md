# iOS native project

This directory contains the iOS Xcode project for **Classic Rummy**.

> ⚠️ **Note:** Building iOS apps requires a macOS machine with Xcode installed. The included GitHub Actions workflow only builds Android. To build iOS:
>
> 1. `cd ios && pod install`
> 2. Open `ClassicRummy.xcworkspace` in Xcode
> 3. Select a target device/simulator and press ▶️
>
> Alternatively, set up an `ios.yml` GitHub Actions workflow on a `macos-latest` runner.

## Files

| File | Purpose |
|---|---|
| `Podfile` | CocoaPods dependency declaration. |
| `ClassicRummy/AppDelegate.h/.mm` | App entry point. |
| `ClassicRummy/Info.plist` | iOS app metadata. |
| `ClassicRummy/LaunchScreen.storyboard` | Splash screen. |
| `ClassicRummy/Images.xcassets/` | App icons and image assets. |

## Generating the Xcode project

If `ClassicRummy.xcodeproj` is missing (e.g. you're starting fresh from this scaffold), you can regenerate it by running:

```bash
npx react-native init ClassicRummy --version 0.73.2 --skip-install
# then copy the generated ios/ClassicRummy.xcodeproj into this directory
```

The `Podfile`, `AppDelegate`, `Info.plist`, and `LaunchScreen.storyboard` in this folder are already configured for the `com.rummyapp.classicrummy` bundle id and "Classic Rummy" display name.
